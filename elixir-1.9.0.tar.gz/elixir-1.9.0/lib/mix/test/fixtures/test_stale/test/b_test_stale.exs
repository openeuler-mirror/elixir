defmodule BTest do
  use ExUnit.Case

  test "f" do
    assert B.f() == :ok
  end
end
