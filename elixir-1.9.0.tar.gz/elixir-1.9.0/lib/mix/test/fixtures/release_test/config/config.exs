use Mix.Config

config :release_test, :static, :was_set
