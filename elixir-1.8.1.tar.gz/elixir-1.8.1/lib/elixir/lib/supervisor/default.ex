defmodule Supervisor.Default do
  @moduledoc false

  def init(args) do
    args
  end
end
