use Mix.Config

config :my_app, :key, :value
