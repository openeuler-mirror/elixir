use Mix.Config
Mix.Config.eval!(Path.join([__DIR__, "good_config.exs"]))
:done
