defmodule UmbrellaCover.MixProject do
  use Mix.Project

  def project do
    [
      apps_path: "apps"
    ]
  end
end
