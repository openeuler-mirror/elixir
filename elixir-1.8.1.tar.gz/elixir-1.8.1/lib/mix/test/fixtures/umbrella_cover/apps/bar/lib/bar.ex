defmodule Bar do
  def hello do
    :world
  end
end
