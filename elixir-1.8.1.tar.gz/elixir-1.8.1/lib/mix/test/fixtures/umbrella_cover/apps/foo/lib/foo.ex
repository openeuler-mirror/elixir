defmodule Foo do
  def hello do
    :world
  end
end
