defmodule BarTest do
  use ExUnit.Case

  test "greets the world" do
    assert Foo.hello() == :world
  end
end
