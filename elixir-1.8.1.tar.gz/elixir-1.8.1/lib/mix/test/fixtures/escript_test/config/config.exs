use Mix.Config

config :escript_test, erl_val: "Erlang value"
